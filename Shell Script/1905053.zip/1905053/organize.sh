#!/bin/bash

if [ $# -lt 4 ]
then
echo "Usage:"
echo "./organize.sh <submission folder> <target> <test> <answer> [-v] [-noexecute]"
echo "-v: verbose"
echo "-noexecute: do not execute code files " 
else
submission="$1"
submission_letter_count=$(expr length "$submission")
sb=$((submission_letter_count+1))
target_path="$2"
target_letter_count=$(expr length "$target_path")  #target folder er nam e koyta character..
ans_path="$4"
test_path="$3"
excel_path="$target_path/result.csv"

if [ "$#" -gt 4 ] && [ "$5" = "-v" ] 
	then
	verbose="1"
	else
	verbose="0"
       
fi

noex="0"
if [ "$#" -gt 4 ] && { [ "$6" = "-noexecute" ] || [ "$5" = "-noexecute" ]; }; then
	noex="1" 
	if [ -d "$target_path" ]
	then
	rm -rf "$target_path"  
	fi   
fi

#extra check




if [ ! -d "$target_path" ]; then
  mkdir "$target_path"
  mkdir "$target_path/C"
  mkdir "$target_path/Java"
  mkdir "$target_path/Python"
  if [ "$noex" = 0 ]
  then
  touch "$excel_path"
  echo "student_id_,type,matched,not_matched" >> "$excel_path"
  fi
  
  #echo "Directory created: $target_path"
#else
  #echo "Directory already exists: $target_path"
  fi

test_file_count=$(find "$test_path" -name "*.txt" | wc -l)
 if [ "$verbose" = "1" ]; then
	echo "Found $test_file_count test files"
 fi

# unzipping 

find "$submission" -name "*.zip" | while IFS= read -r file; do
  file_name=$(basename "$file")
  directory_name="${file_name%.*}"
  unzip -d "$submission/${directory_name:(-7)}" "$file"
  #echo "Unzipped: $file_name"
done
#create an array and store c_files path in them
mapfile -t c_files < <(find "$submission" -name "*.c")
mapfile -t py_files < <(find "$submission" -name "*.py")
mapfile -t java_files < <(find "$submission" -name "*.java")


#:'for file in "${c_files[@]}"; do
  #echo "here"
 # echo "$file"
#done'

# Print the array elements
for path in "${c_files[@]}"  
 do
  first_seven_letters="${path:sb:7}"
  #dir_name="${first_seven_letters%.*}"
  #echo "$path"
  #:'echo "${#c_files[@]}"
  #echo "hiiiiiiiiiiii"
  #echo "$first_seven_letters"
  #echo "$dir_name"'
  des_file="$target_path/C/$first_seven_letters/main.c"
  mkdir -p "$target_path/C/$first_seven_letters"
  cp "$path" "$des_file"
  if [ "$verbose" = "1" ]; then
   echo "Organizing files of $first_seven_letters"
  fi
done



for path in "${java_files[@]}"
 do
  #echo "$path"
  first_seven_letters="${path:sb:7}"
  des_file="$target_path/Java/$first_seven_letters/Main.java"
  mkdir -p "$target_path/Java/$first_seven_letters"
  cp "$path" "$des_file"
  if [ "$verbose" = "1" ]
   then
   echo "Organizing files of $first_seven_letters"
  fi
done



for path in "${py_files[@]}"
 do
  #:'echo "holahola"
  #echo "$path"
  #echo "des path is " '
  first_seven_letters="${path:sb:7}"
  des_file="$target_path/Python/$first_seven_letters/main.py"
  #echo "$des_file"
  mkdir -p "$target_path/Python/$first_seven_letters"
  cp "$path" "$des_file"
  if [ "$verbose" = "1" ]; then
  	echo "Organizing files of $first_seven_letters"
  fi
  
done


#part B




if  [ "$noex" != "1" ] 
then

	

mapfile -t c_f < <(find "$target_path/C" -name "*.c")
mapfile -t j_f < <(find "$target_path/Java" -name "*.java")
mapfile -t p_f < <(find "$target_path/Python" -name "*.py")

for path in "${c_f[@]}"
 do   
   hisab=$((target_letter_count+1+1+1+7))  #target/c/1805053
  tmp="${path:0:hisab}"
  des_file="$tmp/main.out"
  namewithmain="${path:(-14)}"
  name="${namewithmain:0:7}"  #student id extract korsi
  milse=0
  mileNai=0
  gcc -o $des_file $path
  counter=1
    for input_file in "$test_path"/*.txt
      do
    output_file="$tmp/out$counter.txt"
    ans_file="$ans_path/ans$counter.txt"
    ./"$des_file" < "$input_file" > "$output_file"
    
    difference=$(diff "$output_file" "$ans_file")
       if [ -z "$difference" ]; then
          ((milse++))
         else
         ((mileNai++))
       fi
    ((counter++))
     done
     milenai=$((counter-milse-1)) # karon last e counter already 1 bere ache
     if [ "$verbose" = "1" ]; then
     	echo "Executing files of $name"
     fi
      echo "$name,C,$milse,$milenai" >> "$excel_path"
done


for path in "${j_f[@]}"
 do
  #echo "javar file er nam"
  #echo "$path"
  hisab=$((target_letter_count+1+4+1+7))  #target/Java/1805053
  tmp="${path:0:hisab}"
  namewithmain="${path:(-17)}"
  name="${namewithmain:0:7}"  #student id extract korsi
  milse=0
  mileNai=0
  #echo "$tmp"
  src_file="$tmp/Main.java"
    javac "$src_file"
    class_file="$tmp/Main.class"
  counter=1
    for input_file in "$test_path"/*.txt
      do
    output_file="$tmp/out$counter.txt"
    ans_file="$ans_path/ans$counter.txt"
    java  -cp "$(dirname "$class_file")" Main < "$input_file" > "$output_file"
    difference=$(diff "$output_file" "$ans_file")
       if [ -z "$difference" ]; then
          ((milse++))
         else
         ((mileNai++))
       fi
    
    ((counter++))
     done
     milenai=$((counter-milse-1))
     if [ "$verbose" = "1" ]; then
     	echo "Executing files of $name"
     fi
     echo "$name,Java,$milse,$milenai" >> "$excel_path"
done



for path in "${p_f[@]}"
 do
   hisab=$((target_letter_count+1+6+1+7))  #target/Python/1805053
  tmp="${path:0:hisab}"
  namewithmain="${path:(-15)}"
  name="${namewithmain:0:7}"  #student id extract korsi
  milse=0
  mileNai=0
  #:'echo "amar nam"
  #echo "$path"
  #echo "$namewithmain"
  #echo "$name" '
  
  counter=1
    for input_file in "$test_path"/*.txt
      do
    output_file="$tmp/out$counter.txt"
    python3 "$path"  < "$input_file" > "$output_file"
    ans_file="$ans_path/ans$counter.txt"
    #echo "$ans_file"
    #echo "ekhaneeeeeeeeeeeeeeeeeeeee"
    difference=$(diff "$output_file" "$ans_file")
       if [ -z "$difference" ]; then
          ((milse++))
         else
         ((mileNai++))
       fi
       
    ((counter++))
   
     done
     milenai=$((counter-milse-1))
     if [ "$verbose" = "1" ]; then
     	echo "Executing files of $name"
     fi
     echo "$name,Python,$milse,$milenai" >> "$excel_path"
done






fi  # mane noexecute dewa hoy nai oitar if er sesh  















fi #mane atleast 4 ta arg ache oitar if er sesh

