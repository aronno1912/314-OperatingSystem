// g++ -lpthread 1905053.cpp           ./a.out input.txt
//
//sem_wait function is the "wait" operation, also known as the "down" operation. It is used to decrement the value of the semaphore. 
//If the semaphore value is greater than zero, the thread can continue its execution without blocking

//sem_post function is the "signal" operation, also known as the "up" operation. It is used to increment (or "signal")
// the value of the semaphore. If there are threads waiting on the semaphore, it allows one of them to proceed
#include <iostream>
#include <vector>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <bits/stdc++.h>

using namespace std;

const int NUM_PRINTING_STATIONS = 4;
const int NUM_BINDING_STATIONS = 2;
const int ONE_MICROSEC = 1000000;

class StudentData {
public:
    int group_id;
    int student_id;
    int printing_time;
    int arrival_timeP;
    int startPrintingTime;
    int stationId;
    int doneP; // if done printing or not
    bool isGroupLeader;
    int interval;
    //sem_t groupPrintSem; // semaphore to synchronize group members
   
};
int totalGroups;
sem_t* perStudentSema;  //basically semaphore for each student who are in printing station
sem_t lockPS;
sem_t bindingSema;
sem_t entryBookMutex; // For synchronizing access to the entry book
pthread_mutex_t  rwMutex; // For synchronizing access to the reader count
pthread_mutex_t printingMutex;
pthread_mutex_t GroupLeaderMutex;
pthread_t* allStudentsThreads;
int isOccupied[NUM_PRINTING_STATIONS] = { 0, 0, 0, 0 };
//int groupWise = { 0, 0, 0, 0 };
int N, M, w, x, y;
FILE* output_file;
int currentTime = 0;
unordered_map<int, StudentData*> listS;
//pthread_mutex_t entryBookMutex = PTHREAD_MUTEX_INITIALIZER;
int totalSubmissions = 0; // total number of submissions
bool writing = false; // flag to indicate if someone is writing in the entry book
int readerCount = 0;
 poisson_distribution<int> pd(5);
struct Staff{
    public:
    int id;
};


void* randomReadInterval(void* staffDataPtr)
{ 

    //===============The Reader part==============================================
    Staff* staffData = static_cast<Staff*>(staffDataPtr);
    int staff = staffData->id;
    while (true) {
        // Simulate random reading interval
        int readInterval = rand() % 10 + 1;
        sleep(readInterval);

        // Reader starts reading
        // The staff member waits to acquire the rwMutex.
        // This semaphore is used to synchronize access to the readerCount variable, which keeps track of the number of active readers.
        pthread_mutex_lock(&rwMutex);
        readerCount++;
        //If it's the first reader, it acquires the entryBookMutex semaphore, which prevents writers from accessing the entry book.
        if (readerCount ==1) {   
            sem_wait(&entryBookMutex); //down kore dilam
        }
        //the staff member releases the rwMutex to allow other staff members to modify the readerCount
         pthread_mutex_unlock(&rwMutex);

        // Read from the entry book
        fprintf(output_file,"Staff %d has started reading the entry book at time %d. No. of submissions = %d\n", staff, currentTime, totalSubmissions);
          fflush(output_file);
        sleep(y);

        pthread_mutex_lock(&rwMutex);
        readerCount--;
        if (readerCount == 0) {
            sem_post(&entryBookMutex);  //there are no other readers currently reading, and the staff member can release the entryBookMutex to allow other writers to access the entry book
        }
        pthread_mutex_unlock(&rwMutex);
        if(totalSubmissions==totalGroups)break;
    }
    return nullptr;


}


void *timer(void* arg)
{
    clock_t s = clock();
    while (true)
    {
        clock_t f = clock();
        currentTime = (round)(f - s) / CLOCKS_PER_SEC;
    }
}

void informAvailability(StudentData* student)
{
    sem_wait(&lockPS);
    int whichStation = student->stationId - 1;
    isOccupied[whichStation] = 0;
    student->doneP = 1;

    // First, inform groupmates
    for (int i = (student->group_id - 1) * M + 1; i <= (student->group_id * M); i++)
    {
        auto it = listS.find(i);
        if (it != listS.end()) {
            StudentData* sd = it->second;
           //sd is my groupmate.........................
            if (sd->stationId == student->stationId && i != student->student_id && sd->doneP == 0 && currentTime >= sd->arrival_timeP)
            {
                isOccupied[whichStation] = 1;
                sem_post(&perStudentSema[sd->student_id - 1]); //wakeup my groupmate, 0 theke value up kore dilam
                pthread_mutex_lock(&printingMutex);
                fprintf(output_file,"Student %d has informed availability to %d of same group\n", student->student_id, sd->student_id);
                
                fflush(output_file);
                pthread_mutex_unlock(&printingMutex);
                break;
            }
        }
    }

    // Then, inform students of different groups
    if (isOccupied[whichStation] == 0)
    {
        for (int i = 1; i <= N; i++)
        {
            auto it = listS.find(i);
            if (it != listS.end()) {
                StudentData* sd = it->second;

                if (i >= (student->group_id - 1) * M + 1 && i <= (student->group_id * M))continue;
                if (sd->stationId == student->stationId && sd->doneP == 0 && currentTime >= sd->arrival_timeP)
                {
                    isOccupied[whichStation] = 1;
                    sem_post(&perStudentSema[sd->student_id - 1]);
                    pthread_mutex_lock(&printingMutex);
                    fprintf(output_file,"Student %d has informed availability to %d of different group\n", student->student_id, sd->student_id);
                    
                       fflush(output_file);
                    pthread_mutex_unlock(&printingMutex);
                    break;
                }
            }
        }
    }
    sem_post(&lockPS);
}

//============================================the binding task and then so on =========================================================================
void task2(StudentData* student)
{
    sem_wait(&bindingSema);
    pthread_mutex_lock(&printingMutex);
    fprintf(output_file,"Group %d has started binding at time %d\n", student->group_id, currentTime);
    fflush(output_file);
    pthread_mutex_unlock(&printingMutex);
    sleep(x);
    pthread_mutex_lock(&printingMutex);
    fprintf(output_file,"Group %d has finished binding at time %d\n", student->group_id, currentTime);
      fflush(output_file);
    pthread_mutex_unlock(&printingMutex);
    sem_post(&bindingSema);
   

   int anyRandomwait=rand()%4+1;
   sleep(anyRandomwait); //to mimic real life scenario. as one can't immediately start writing just after finishing binding.
    // Group leader writes in the entry book

    //==============The writing part=============================
    //The group leader waits for the entryBookMutex semaphore to ensure mutual exclusion for writing in the entry book.
    //Finally, the group leader releases the entryBookMutex semaphore to allow other group leaders to write in the entry book.
    //if (student->isGroupLeader) {
        sem_wait(&entryBookMutex);
        fprintf(output_file,"Group %d (Leader: Student %d) is writing in the entry book(report submission) at time %d\n", student->group_id, student->student_id, currentTime);
        fflush(output_file);
        totalSubmissions++;
         sleep(y);
        //fprintf(output_file,"No. of submissions = %d\n", totalSubmissions);
        sem_post(&entryBookMutex);
   // }
}


void* task1(void* sdu)
{    
    
     
    StudentData* sd = (StudentData*)sdu;
    int whichStation = sd->stationId - 1;
    int randomDelay = rand() % 10+2;
    sleep(randomDelay);
    sd->arrival_timeP=currentTime;
    //===========================thinking state============================================
    pthread_mutex_lock(&printingMutex);
    fprintf(output_file,"Student %d has arrived at the print station %d at time %d\n", sd->student_id, sd->stationId, currentTime);
     fflush(output_file);
    pthread_mutex_unlock(&printingMutex);
     
     //==========Take_fork() or occupy_station=============================================
    sem_wait(&lockPS); //want to occupy the printing station to print
    // If not occupied
    if (isOccupied[whichStation] == 0 && sd->doneP == 0)
    {
        isOccupied[whichStation] = 1;
        sem_post(&perStudentSema[sd->student_id - 1]);   //up kore dilam 0 theke
        
    }
    sem_post(&lockPS);
    sem_wait(&perStudentSema[sd->student_id - 1]);  //now the student who got  the station can down it
    //======================eat() or here start_printing()======================================================
    pthread_mutex_lock(&printingMutex);
    fprintf(output_file,"Student %d has started printing at time %d\n", sd->student_id, currentTime);
    fflush(output_file);
    pthread_mutex_unlock(&printingMutex);
    sleep(w);
    //=========================put_Forks() or leave the station=====================================================
    pthread_mutex_lock(&printingMutex);
    fprintf(output_file,"Student %d has finished printing at time %d\n", sd->student_id, currentTime);
    fflush(output_file);
    pthread_mutex_unlock(&printingMutex);
    //sd->doneP=1;
    //sd->groupPrintCount++;
    informAvailability(sd);

     // not the leader.... so thread shesh......................
        if(!sd->isGroupLeader)
        return nullptr;
    // he is leader,,, so  wait to finish for his groupmates
     for (int i = (sd->group_id - 1) * M + 1; i < (sd->group_id * M); i++)
    {
        
            pthread_join(allStudentsThreads[i - 1], NULL);
        
    }
    int anyRandomwait=rand()%4+1;
    sleep(anyRandomwait); //to mimic real life scenario. as one can't immediately start binding just at the time it found all have finished printing
        task2(sd);  // go for binding station
      
    return nullptr;
}

int main()
{
    ifstream input_file;
    static random_device randm;
    static mt19937 gen(randm());
   
    input_file.open("input.txt");
    input_file >> N>> M;
    input_file >> w >> x >> y;
    input_file.close();
    output_file = fopen("output.txt", "w");
    sem_init(&lockPS, 0, 1);
    sem_init(&bindingSema, 0, NUM_BINDING_STATIONS);
    pthread_mutex_init(&printingMutex, 0); //passing NULL
    pthread_mutex_init(&GroupLeaderMutex, 0);
    sem_init(&entryBookMutex, 0, 1); //how many writers can get access
     pthread_mutex_init(&rwMutex, 0); 
    perStudentSema = new sem_t[N];  //jodi keu ps occupy korte pare taile value 1 hoye jabe.
    allStudentsThreads = new pthread_t[N];
    totalGroups=(int)N/M;
    for (int i = 0; i < N; i++)
    {
        sem_init(&perStudentSema[i], 0, 0);
    }

    pthread_t tt;
    pthread_create(&tt, nullptr, timer, nullptr);
     pthread_t staff1_thread, staff2_thread;
     Staff staffData1 = {1}; // Staff 1
     Staff staffData2 = {2};
    pthread_create(&staff1_thread, nullptr, randomReadInterval, &staffData1);
    pthread_create(&staff2_thread, nullptr, randomReadInterval, &staffData2);

   
    for (int i = 1; i <= N; i++)
    {
        int student_id = i;
        
        //arrival_time += currentTime;
        //currentTime += currentTime;
       
        StudentData* data = new StudentData;
        data->student_id = student_id;
        data->group_id = (i - 1) / M + 1;
        data->printing_time = w;
        data->stationId = (i % 4) + 1;
        data->doneP = 0;
        data->interval = pd(gen);
        //data->groupPrintCount=0;
        //data->arrival_timeP = currentTime;
        if ((data->group_id * M) == data->student_id)
            data->isGroupLeader = true;
        else
            data->isGroupLeader = false;

        listS.emplace(data->student_id, data);
        pthread_create(&allStudentsThreads[i - 1], nullptr, task1, (void*)data);
    }

    
    for (int i = 0; i < N; i++)
    {  
        if((i+1)%M==0) //the leaderThread
        pthread_join(allStudentsThreads[i], nullptr);
    }
     pthread_join(staff1_thread, nullptr);
     pthread_join(staff2_thread, nullptr);

    delete[] allStudentsThreads;
    delete[] perStudentSema;
    fclose(output_file);
    return 0;
}
